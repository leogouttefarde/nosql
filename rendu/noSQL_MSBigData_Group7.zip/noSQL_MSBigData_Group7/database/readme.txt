

To create the database, simply run the 'create_db.cql' script from your neo4j shell.
You can use the commands bellow from this folder, change the NEO4J path if required.

# Write your neo4j installation path in NEO4J
NEO4J=~/*neo4j-community*
$NEO4J/bin/neo4j-shell -file create_db.cql

